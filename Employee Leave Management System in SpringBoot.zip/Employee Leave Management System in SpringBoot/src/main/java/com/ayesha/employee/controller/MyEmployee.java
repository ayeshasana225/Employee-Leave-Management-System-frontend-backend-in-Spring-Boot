package com.ayesha.employee.controller;

import com.ayesha.employee.model.Employee;
import com.ayesha.employee.model.Manager;
import com.ayesha.employee.repository.ManagerRepository;
import com.ayesha.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class MyEmployee {

    static Employee foundEmployee;
    private final EmployeeService employeeService;
    private final ManagerRepository managerRepository;

    @Autowired
    public MyEmployee(EmployeeService employeeService, ManagerRepository managerRepository) {
        this.employeeService = employeeService;
        this.managerRepository = managerRepository;
    }

    // employeesignup
    @GetMapping("/employeesignup")
    public String showSignUpForm(Model employee) {
        employee.addAttribute("employee", new Employee());
        return "employeeSignup";
    }

    @PostMapping("/employeesignup")
    public String signUp(@ModelAttribute Employee employee) {
        employeeService.saveEmployee(employee);

        // Fetch the saved employee data
        Employee savedEmployee = employeeService.findByUsername(employee.getUsername());

        // Save the employee data to the manager table
        Manager manager = new Manager();
        manager.setEmpname(savedEmployee.getName());
        manager.setEmpusername(savedEmployee.getUsername());
        manager.setEmpemail(savedEmployee.getEmail());
        manager.setEmployee(savedEmployee);  // Set the employee for the manager
        managerRepository.save(manager);

        return "redirect:employeesignin";
    }


    //employeesignin
    @GetMapping("/employeesignin")
    public String showSignInForm(Model employee) {
        employee.addAttribute("employee", new Employee());
        return "employeesignin";
    }

    @PostMapping("/employeesignin")
    public String signIn(@ModelAttribute Employee employee) {
        foundEmployee = employeeService.findByUsername(employee.getUsername());
        if (foundEmployee != null && foundEmployee.getPassword().equals(employee.getPassword())) {
            return "redirect:employee";
        } else {
            return "redirect:employeesignin?invalid";
        }
    }

    //employee
    @GetMapping("/employee")
    public String employee(Model employee) {
        if (foundEmployee != null) {
            employee.addAttribute("employee", foundEmployee);
            System.out.println("Employee ID:  " + foundEmployee.getId());
            System.out.println("Employee Name:  " + foundEmployee.getName());
            return "employee";
        }
        return "redirect:employeesignin?logout";
    }

    //update
    @GetMapping("/update")
    public String update(Model employee) {
        if (foundEmployee != null) {
            employee.addAttribute("employee", foundEmployee);
            System.out.println("Employee ID:  " + foundEmployee.getId());
            System.out.println("Employee Name:  " + foundEmployee.getName());
            return "update";
        }
        return "redirect:employeesignin?logout";
    }

//manage employee
@GetMapping("/manage_employee")
public String manage_employee(Model model) {
    List<Employee> allEmployees = employeeService.getAllEmployees();
    model.addAttribute("employees", allEmployees);
    return "manage_employee";
}

    // Delete employee by ID
    @GetMapping("/deleteEmployee/{id}")
    @ResponseBody
    public Map<String, String> deleteEmployee(@PathVariable Long id) {
        Map<String, String> response = new HashMap<>();
        try {
            // Fetch the employee by ID
            Employee employeeToDelete = employeeService.getEmployeeById(id);

            // Delete the employee from both Employee and Manager tables
            employeeService.deleteEmployeeAndManager(employeeToDelete);

            response.put("Employee is deleted successfully", "true");
        } catch (Exception e) {
            response.put("success", "false");
            response.put("error", e.getMessage());
        }
        return response;
    }
    //leave status
    @GetMapping("/leave_status")
    public String leave_status(Model model) {
        if (foundEmployee != null) {
            // Fetch leave details from Manager table
            List<Manager> pendingLeaves = managerRepository.findByEmpusername(foundEmployee.getUsername());

            // Check and set status to "Pending" if it's null
            for (Manager leave : pendingLeaves) {
                if (leave.getLeaveStatus() == null) {
                    leave.setLeaveStatus("Pending");
                }
            }

            model.addAttribute("pendingLeaves", pendingLeaves);
            return "leave_status";
        }
        return "redirect:leave_status";
    }


    //applyleave
    @GetMapping("/apply_leave")
    public String apply_leave(Model employee) {
        employee.addAttribute("employee", new Employee());
        return "apply_leave";
    }
    @PostMapping("/apply_leave")
    public String apply_leave(@RequestParam String username, @RequestParam String leaveType,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        if (foundEmployee != null) {
            // Save leave details in the Manager table
            Manager manager = new Manager();
            manager.setEmpname(foundEmployee.getName());
            manager.setEmpusername(foundEmployee.getUsername());
            manager.setEmpemail(foundEmployee.getEmail());
            manager.setEmployee(foundEmployee);
            manager.setLeaveType(leaveType);
            manager.setStartDate(startDate);
            manager.setEndDate(endDate);

            managerRepository.save(manager);

            return "redirect:apply_leave?success";
        }
        return "redirect:employeesignin?logout";
    }
//pendingleaves
@GetMapping("/pending_leave")
public String pending_leave(Model model) {
    if (foundEmployee != null) {
        // Fetch leave details from Manager table
        List<Manager> pendingLeaves = managerRepository.findByEmpusername(foundEmployee.getUsername());
        model.addAttribute("pendingLeaves", pendingLeaves);
        return "pending_leave";
    }
    return "redirect:pending_leave";
}

//this handle both approval and rejection of leave
@RequestMapping(value = "/leave_action/{managerId}", method = {RequestMethod.GET, RequestMethod.POST})
public String leaveAction(@PathVariable Long managerId,
                          @RequestParam(required = false) String action) {
    Manager manager = managerRepository.findById(managerId)
            .orElseThrow(() -> new RuntimeException("Leave not found with id: " + managerId));

    if ("approve".equals(action)) {
        // Update leave status to Approved
        manager.setLeaveStatus("Approved");
    } else if ("reject".equals(action)) {
        // Update leave status to Rejected
        manager.setLeaveStatus("Rejected");
    }

    managerRepository.save(manager);

    return "redirect:/pending_leave";
}
/*deleting pending leave
@DeleteMapping("/delete_leave/{managerId}")
@ResponseBody
public Map<String, String> deleteLeave(@PathVariable Long managerId) {
    Map<String, String> response = new HashMap<>();
    try {
        // Delete the leave entry from the database
        managerRepository.deleteById(managerId);

        response.put("Leave entry deleted successfully", "true");
    } catch (Exception e) {
        response.put("success", "false");
        response.put("error", e.getMessage());
    }
    return response;
}*/


    //others
    @GetMapping("/allowedleaves")
    public String allowedleaves() {
        return "allowedleaves";
    }

    @GetMapping("/index")
    public String welcome() {
        return "index";
    }

    @GetMapping("/welcomeemployee")
    public String welcomeemployee() {
        return "welcomeemployee";
    }


    @GetMapping("/add_employee")
    public String add_employee() {
        return "add_employee";
    }

    @GetMapping("/add_leave_type")
    public String add_leave_type() {
        return "add_leave_type";
    }

    @GetMapping("/add_user")
    public String add_user() {
        return "add_user";
    }


    @GetMapping("/approve_leave")
    public String approve_leave() {
        return "approve_leave";
    }

    @GetMapping("/index1")
    public String index1() {
        return "index1";
    }

    @GetMapping("/leave_details")
    public String leave_details() {
        return "leave_details";
    }


    @GetMapping("/manage_leave_type")
    public String manage_leave_type() {
        return "manage_leave_type";
    }

    @GetMapping("/manage_user")
    public String manage_user() {
        return "manage_user";
    }

    @GetMapping("/managersignin")
    public String managersignin() {
        return "managersignin";
    }

    @GetMapping("/managersignup")
    public String managersignup() {
        return "managersignup";
    }

    @GetMapping("/not_approve_leave")
    public String not_approve_leave() {
        return "not_approve_leave";
    }

    @GetMapping("/reports")
    public String reports() {
        return "reports";
    }



    @GetMapping("/update_password")
    public String update_password() {
        return "update_password";
    }

    @GetMapping("/welcomemanager")
    public String welcomemanager() {
        return "welcomemanager";
    }

}