// Manager.java
package com.ayesha.employee.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;

@Getter
@Setter
@Entity
public class Manager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long managerid;

    private String empname;
    private String empusername;
    private String empemail;
    private String leaveType;
    private LocalDate startDate;
    private LocalDate endDate;
    private String leaveStatus;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;
}
