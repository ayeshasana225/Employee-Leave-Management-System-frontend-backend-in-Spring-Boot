// EmployeeRepository.java
package com.ayesha.employee.repository;

import com.ayesha.employee.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Employee findByUsername(String username);

    Optional<Employee> findById(Long id);
}