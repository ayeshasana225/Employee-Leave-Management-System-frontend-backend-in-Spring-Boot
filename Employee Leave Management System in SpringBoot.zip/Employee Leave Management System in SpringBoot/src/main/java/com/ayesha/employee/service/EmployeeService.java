// EmployeeService.java
package com.ayesha.employee.service;

import com.ayesha.employee.model.Employee;
import com.ayesha.employee.repository.EmployeeRepository;
import com.ayesha.employee.repository.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;
    ManagerRepository managerRepository;

    public void saveEmployee(Employee employee) {
        // Perform any additional validation or business logic if needed
        employeeRepository.save(employee);
    }

    public Employee findByUsername(String username) {
        return employeeRepository.findByUsername(username);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id: " + id));
    }

    public void deleteEmployeeAndManager(Employee employee) {
        // Delete the employee from both Employee and Manager tables
        // Ensure that the relationships are set up correctly with cascade options
        // For example, if Employee has a OneToMany relationship with Manager, cascade options should be set.
        // Also, make sure that orphanRemoval is set to true if necessary.
        employeeRepository.delete(employee);
    }


}